### Abstract

You will be implementing a SJSU ChatBOT using [Slack API](https://api.slack.com/)

### Requirements

- 

Example

_USER INPUT_
```sh
when is cmpe273 section 1 final exam
```

_BOT RESPONSE_
```sh
CMPE273 section 1 final exam will be held at May 24th at 5:15pm.
```
