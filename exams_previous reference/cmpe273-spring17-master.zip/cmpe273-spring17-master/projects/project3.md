### Abstract

You will be implementing a sensor data sharing FOG platform using Raspberry Pi 3.

### Requirements.

* Capture data like temperature, humidity, and gas leak detection and share in your local FOG network.
