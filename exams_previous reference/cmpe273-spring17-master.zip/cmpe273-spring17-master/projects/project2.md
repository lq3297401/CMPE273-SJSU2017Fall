### Abstract

You will be building a pre-requisite check system using machine learning OpenCV tool.

### Requirements

* Upload the sample data or template with fields to be extracted.
* Capture with screenshot using a solution like [html2canvas](http://html2canvas.hertzen.com/)
* Send the submission confirmation email and store the data into database.
